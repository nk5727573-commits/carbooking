
import React from 'react';
import { CarType } from './types';

export const CAR_MODELS = {
  [CarType.ECONOMY]: {
    name: 'Toyota Corolla',
    baseRate: 5,
    perKm: 1.5,
    icon: '🚗',
    capacity: 4
  },
  [CarType.PREMIUM]: {
    name: 'Honda Accord',
    baseRate: 8,
    perKm: 2.2,
    icon: '🚘',
    capacity: 4
  },
  [CarType.LUXURY]: {
    name: 'BMW 5 Series',
    baseRate: 15,
    perKm: 4.5,
    icon: '✨',
    capacity: 4
  },
  [CarType.XL]: {
    name: 'Chevrolet Suburban',
    baseRate: 12,
    perKm: 3.0,
    icon: '🚐',
    capacity: 7
  }
};

export const MOCK_DOCS = [
  {
    title: 'Project Architecture',
    content: `The SwiftRide Pro application follows a Clean Architecture pattern, separating concerns between UI (React Components), Business Logic (Hooks/Services), and Data (State Management). For the mobile-first experience, we use a single-container design that ensures responsiveness across iOS and Android viewports.`
  },
  {
    title: 'Real-time Tracking Engine',
    content: `Our tracking system utilizes a simulated GPS interpolation algorithm. It calculates the bearing between coordinates and updates the vehicle position at a 60fps refresh rate using requestAnimationFrame for smooth movement, mimicking a live WebSocket feed.`
  },
  {
    title: 'Dynamic Pricing Algorithm',
    content: `Prices are calculated using: Total = Base_Fare + (Distance × Rate_Per_KM) + (Passengers × Service_Fee). We also integrate Gemini AI to provide context-aware surges based on simulated weather or event density.`
  },
  {
    title: 'Security & Verification',
    content: `The system implements a 4-digit Secure OTP (One-Time Password) generated on booking. Drivers must input this into their interface to start the trip, ensuring person-to-person verification. All data transmission is encrypted (TLS 1.3).`
  }
];
