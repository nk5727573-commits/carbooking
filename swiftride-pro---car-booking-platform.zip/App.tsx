
import React, { useState, useEffect } from 'react';
import { AppState, User, RideDetails, CarType } from './types';
import { CAR_MODELS } from './constants';
import MapVisualizer from './components/MapVisualizer';
import { getTravelInsights, calculateSmartPrice } from './services/geminiService';

const App: React.FC = () => {
  const [appState, setAppState] = useState<AppState>(AppState.LOGIN);
  const [user, setUser] = useState<User | null>(null);
  const [ride, setRide] = useState<RideDetails | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [aiResponse, setAiResponse] = useState<{text: string, links: string[]}>({text: '', links: []});
  
  // Form States
  const [pickup, setPickup] = useState('72nd St, Central Park');
  const [destination, setDestination] = useState('Hudson Yards, NY');
  const [passengers, setPassengers] = useState(1);
  const [carType, setCarType] = useState<CarType>(CarType.ECONOMY);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setTimeout(() => {
      setUser({ id: '1', name: 'Alex', email: 'alex@swiftride.pro' });
      setAppState(AppState.HOME);
      setIsLoading(false);
    }, 800);
  };

  const handleBookingSearch = async () => {
    setIsLoading(true);
    const distance = 5.2; 
    const basePrice = CAR_MODELS[carType].baseRate + (distance * CAR_MODELS[carType].perKm);
    
    // AI enhanced features
    const [dynamicFactor, insights] = await Promise.all([
      calculateSmartPrice(distance, passengers, carType),
      getTravelInsights(pickup, destination)
    ]);
    
    setAiResponse(insights);
    const otp = Math.floor(1000 + Math.random() * 9000).toString();
    
    setRide({
      pickup,
      destination,
      passengers,
      carType,
      price: Math.round((basePrice + (passengers * 1.5)) * dynamicFactor),
      otp,
      distance
    });
    
    setAppState(AppState.BOOKING);
    setIsLoading(false);
  };

  return (
    <div className="flex flex-col h-screen w-full max-w-md mx-auto bg-[#020617] text-slate-100 overflow-hidden shadow-[0_0_50px_rgba(0,0,0,0.5)] border-x border-slate-800">
      
      {/* Premium Header */}
      {appState !== AppState.LOGIN && (
        <header className="p-5 flex items-center justify-between z-20">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-xl flex items-center justify-center shadow-lg shadow-blue-900/40">
              <span className="font-black text-xl italic">S</span>
            </div>
            <div>
              <h1 className="font-bold text-sm tracking-tight">SWIFTRIDE</h1>
              <p className="text-[10px] text-blue-500 font-bold uppercase tracking-widest leading-none">Pro Edition</p>
            </div>
          </div>
          <button className="w-10 h-10 rounded-full glass flex items-center justify-center text-lg">
            🔔
          </button>
        </header>
      )}

      <main className="flex-1 overflow-y-auto relative no-scrollbar">
        
        {/* Login - Futuristic */}
        {appState === AppState.LOGIN && (
          <div className="flex flex-col h-full p-10 justify-center">
            <div className="mb-12">
              <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center mb-6 glow-blue">
                <span className="text-3xl font-black">S</span>
              </div>
              <h2 className="text-4xl font-black mb-2 tracking-tight">Move Smarter.</h2>
              <p className="text-slate-500 font-medium">Experience the next generation of premium travel.</p>
            </div>
            <form onSubmit={handleLogin} className="space-y-5">
              <div className="space-y-1">
                <input 
                  type="email" 
                  placeholder="Email Address"
                  defaultValue="vip@swiftride.pro"
                  className="w-full px-5 py-4 bg-slate-900/50 border border-slate-800 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-slate-100 placeholder:text-slate-600"
                />
              </div>
              <div className="space-y-1">
                <input 
                  type="password" 
                  placeholder="Password"
                  defaultValue="********"
                  className="w-full px-5 py-4 bg-slate-900/50 border border-slate-800 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-slate-100 placeholder:text-slate-600"
                />
              </div>
              <button 
                type="submit"
                className="w-full bg-blue-600 text-white py-4 rounded-2xl font-bold text-lg hover:bg-blue-500 transition-all glow-blue active:scale-95"
              >
                {isLoading ? 'Decrypting...' : 'Get Started'}
              </button>
            </form>
          </div>
        )}

        {/* Home / Booking Dashboard */}
        {appState === AppState.HOME && (
          <div className="h-full flex flex-col p-4 gap-4">
            <div className="flex-1 min-h-[40%] rounded-3xl overflow-hidden relative">
              <MapVisualizer isTracking={false} />
            </div>
            
            <div className="glass rounded-[2rem] p-6 space-y-6 relative -mt-16 mx-2 border-t border-slate-700/50">
              <div className="space-y-4">
                <div className="flex items-center gap-4 bg-slate-900/40 p-1 rounded-2xl border border-slate-800">
                   <div className="flex-1 space-y-3 p-2">
                     <div className="flex items-center gap-3">
                       <div className="w-2 h-2 rounded-full bg-blue-400"></div>
                       <input 
                         value={pickup} 
                         onChange={e => setPickup(e.target.value)}
                         className="bg-transparent text-sm w-full outline-none font-medium text-slate-300" 
                       />
                     </div>
                     <div className="h-[1px] bg-slate-800 mx-2"></div>
                     <div className="flex items-center gap-3">
                       <div className="w-2 h-2 rounded-full bg-green-400"></div>
                       <input 
                         value={destination} 
                         onChange={e => setDestination(e.target.value)}
                         className="bg-transparent text-sm w-full outline-none font-bold text-white" 
                       />
                     </div>
                   </div>
                </div>

                <div className="flex gap-3 overflow-x-auto no-scrollbar pb-2">
                  {Object.values(CarType).map(type => (
                    <button 
                      key={type}
                      onClick={() => setCarType(type)}
                      className={`flex-shrink-0 px-6 py-4 rounded-2xl flex flex-col items-center gap-2 border transition-all ${
                        carType === type ? 'bg-blue-600 border-blue-400 text-white' : 'glass border-slate-800 text-slate-400'
                      }`}
                    >
                      <span className="text-xl">{CAR_MODELS[type].icon}</span>
                      <span className="text-[10px] font-bold uppercase">{type}</span>
                    </button>
                  ))}
                </div>
              </div>

              <button 
                onClick={handleBookingSearch}
                disabled={isLoading}
                className="w-full bg-white text-slate-950 py-4 rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-slate-200 transition active:scale-[0.98]"
              >
                {isLoading ? 'Scanning Grid...' : 'Find Captain'}
              </button>
            </div>
          </div>
        )}

        {/* Ride Confirmation Details */}
        {appState === AppState.BOOKING && ride && (
          <div className="p-6 space-y-6 animate-slideUp h-full">
            <div className="flex justify-between items-end mb-4">
              <div>
                <h2 className="text-3xl font-black tracking-tight">Trip Details</h2>
                <p className="text-slate-500 font-medium">AI-Optimized route secured</p>
              </div>
              <div className="text-right">
                 <p className="text-[10px] font-black text-blue-500 uppercase">Estimated</p>
                 <p className="text-2xl font-bold text-white">${ride.price}</p>
              </div>
            </div>

            <div className="glass rounded-[2rem] p-6 space-y-6">
               <div className="flex items-center gap-5">
                 <div className="w-20 h-20 bg-slate-800/50 rounded-2xl flex items-center justify-center text-5xl">
                   {CAR_MODELS[ride.carType].icon}
                 </div>
                 <div>
                   <h3 className="text-xl font-bold">{CAR_MODELS[ride.carType].name}</h3>
                   <div className="flex gap-2 mt-1">
                     <span className="text-[10px] bg-blue-500/20 text-blue-400 px-2 py-0.5 rounded-full font-bold">PREMIUM</span>
                     <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded-full font-bold">MAX 4</span>
                   </div>
                 </div>
               </div>

               <div className="p-5 bg-slate-900/50 rounded-2xl border border-slate-800">
                  <h4 className="text-[10px] font-black text-blue-500 uppercase mb-3">Satellite Intelligence</h4>
                  <p className="text-xs text-slate-300 leading-relaxed italic">
                    "{aiResponse.text}"
                  </p>
                  {aiResponse.links.length > 0 && (
                    <div className="mt-3 flex flex-wrap gap-2">
                      {aiResponse.links.map((link, i) => (
                        <a key={i} href={link} target="_blank" className="text-[10px] text-blue-400 underline font-bold">Map Reference</a>
                      ))}
                    </div>
                  )}
               </div>

               <div className="flex gap-4">
                  <button onClick={() => setAppState(AppState.HOME)} className="flex-1 py-4 text-slate-500 font-bold hover:text-white transition">Back</button>
                  <button onClick={() => setAppState(AppState.TRACKING)} className="flex-[2] bg-blue-600 text-white py-4 rounded-2xl font-bold glow-blue">Confirm Ride</button>
               </div>
            </div>
          </div>
        )}

        {/* Real-time Pursuit View */}
        {appState === AppState.TRACKING && ride && (
          <div className="h-full flex flex-col">
            <div className="flex-1 relative">
              <MapVisualizer isTracking={true} onArrived={() => alert('Captain has arrived!')} />
              
              <div className="absolute top-6 left-6 right-6 flex justify-between">
                <div className="glass px-4 py-2 rounded-full text-xs font-bold flex items-center gap-2">
                   <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
                   LIVE TRACKING
                </div>
                <div className="glass px-4 py-2 rounded-full text-xs font-bold">
                   ETA 4 MIN
                </div>
              </div>
            </div>
            
            <div className="glass rounded-t-[2.5rem] p-8 space-y-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="relative">
                    <img src="https://i.pravatar.cc/150?u=captain" className="w-14 h-14 rounded-2xl border-2 border-blue-500 object-cover" alt="Driver" />
                    <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-blue-600 rounded-full border-2 border-slate-900 flex items-center justify-center text-[10px]">✔</div>
                  </div>
                  <div>
                    <h3 className="font-bold text-lg text-white">Captain Marcus</h3>
                    <p className="text-xs text-slate-500 font-medium">Tesla Model S • Blue</p>
                  </div>
                </div>
                <div className="text-center">
                  <p className="text-[10px] font-black text-slate-500 uppercase mb-1">Pass-Key</p>
                  <div className="px-4 py-2 bg-blue-600 rounded-xl text-xl font-black tracking-widest">{ride.otp}</div>
                </div>
              </div>

              <div className="flex gap-4">
                <button className="flex-1 glass py-4 rounded-2xl flex items-center justify-center gap-2 font-bold text-sm">
                   💬 Chat
                </button>
                <button onClick={() => setAppState(AppState.HOME)} className="flex-1 bg-red-500/10 border border-red-500/20 text-red-500 py-4 rounded-2xl font-bold text-sm">
                   Cancel
                </button>
              </div>
            </div>
          </div>
        )}

      </main>

      {/* Futuristic Nav */}
      {appState !== AppState.LOGIN && (
        <nav className="h-20 border-t border-slate-800 bg-slate-950 flex items-center justify-around px-8">
          <button onClick={() => setAppState(AppState.HOME)} className={`p-2 transition-all ${appState === AppState.HOME ? 'text-blue-500' : 'text-slate-600'}`}>
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg>
          </button>
          <button onClick={() => setAppState(AppState.DOCS)} className={`p-2 transition-all ${appState === AppState.DOCS ? 'text-blue-500' : 'text-slate-600'}`}>
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
          </button>
          <button className="p-2 text-slate-600">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
          </button>
        </nav>
      )}
    </div>
  );
};

export default App;
