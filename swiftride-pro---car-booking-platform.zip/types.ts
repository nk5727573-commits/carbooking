
export enum AppState {
  LOGIN = 'LOGIN',
  HOME = 'HOME',
  SEARCHING = 'SEARCHING',
  BOOKING = 'BOOKING',
  TRACKING = 'TRACKING',
  DOCS = 'DOCS'
}

export interface User {
  id: string;
  name: string;
  email: string;
}

export interface RideDetails {
  pickup: string;
  destination: string;
  passengers: number;
  carType: CarType;
  price: number;
  otp: string;
  distance: number;
}

export enum CarType {
  ECONOMY = 'Economy',
  PREMIUM = 'Premium',
  LUXURY = 'Luxury',
  XL = 'XL'
}

export interface MapPoint {
  lat: number;
  lng: number;
}

export interface DocumentSection {
  title: string;
  content: string;
}
