
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getTravelInsights = async (pickup: string, dest: string) => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Provide travel insights and current traffic conditions for a ride from ${pickup} to ${dest}. Include approximate travel time and a quick tip.`,
      config: {
        tools: [{ googleMaps: {} }],
        temperature: 0.7,
      },
    });
    
    // Extract map links if available
    const mapsLinks = response.candidates?.[0]?.groundingMetadata?.groundingChunks
      ?.filter(chunk => chunk.maps?.uri)
      .map(chunk => chunk.maps?.uri) || [];

    return {
      text: response.text || "Safe journey ahead!",
      links: mapsLinks
    };
  } catch (error) {
    console.error("Gemini Error:", error);
    return { text: "Enjoy your safe journey with SwiftRide Pro!", links: [] };
  }
};

export const calculateSmartPrice = async (distance: number, passengers: number, carType: string) => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Calculate a mock dynamic price multiplier for a ${carType} ride covering ${distance}km with ${passengers} passengers. Return ONLY a single number (e.g. 1.15).`,
      config: {
        temperature: 0.1,
      },
    });
    return parseFloat(response.text?.trim() || "1.0") || 1.0;
  } catch (error) {
    return 1.0;
  }
};
