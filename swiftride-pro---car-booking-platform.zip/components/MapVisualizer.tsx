
import React, { useEffect, useState, useRef } from 'react';

interface MapVisualizerProps {
  isTracking: boolean;
  onArrived?: () => void;
}

const MapVisualizer: React.FC<MapVisualizerProps> = ({ isTracking, onArrived }) => {
  const [carPos, setCarPos] = useState({ x: 15, y: 75 });
  const [rotation, setRotation] = useState(45);
  const requestRef = useRef<number>(0);
  
  const pathPoints = [
    { x: 15, y: 75 },
    { x: 40, y: 65 },
    { x: 45, y: 45 },
    { x: 75, y: 35 },
    { x: 85, y: 20 }
  ];

  const animate = () => {
    if (!isTracking) return;
    
    setCarPos(prev => {
      const target = pathPoints[pathPoints.length - 1];
      const dx = target.x - prev.x;
      const dy = target.y - prev.y;
      const distance = Math.sqrt(dx * dx + dy * dy);
      
      if (distance < 0.5) {
        if (onArrived) onArrived();
        return prev;
      }
      
      const speed = 0.08;
      const vx = (dx / distance) * speed;
      const vy = (dy / distance) * speed;
      
      const angle = Math.atan2(dy, dx) * (180 / Math.PI);
      setRotation(angle + 90);

      return {
        x: prev.x + vx,
        y: prev.y + vy
      };
    });
    
    requestRef.current = requestAnimationFrame(animate);
  };

  useEffect(() => {
    if (isTracking) {
      requestRef.current = requestAnimationFrame(animate);
    } else {
      setCarPos(pathPoints[0]);
    }
    return () => cancelAnimationFrame(requestRef.current);
  }, [isTracking]);

  return (
    <div className="relative w-full h-full bg-[#020617] overflow-hidden rounded-3xl border border-slate-800/50">
      <svg className="absolute inset-0 w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
        <defs>
          <radialGradient id="mapGlow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#1e293b" stopOpacity="0.4" />
            <stop offset="100%" stopColor="#020617" stopOpacity="1" />
          </radialGradient>
        </defs>
        
        {/* Dark Grid Lines */}
        <pattern id="grid" width="10" height="10" patternUnits="userSpaceOnUse">
          <path d="M 10 0 L 0 0 0 10" fill="none" stroke="#1e293b" strokeWidth="0.2" />
        </pattern>
        <rect width="100" height="100" fill="url(#grid)" />
        <rect width="100" height="100" fill="url(#mapGlow)" />

        {/* Abstract Dark City Blocks */}
        <rect x="5" y="5" width="20" height="20" fill="#0f172a" rx="2" />
        <rect x="35" y="10" width="15" height="25" fill="#0f172a" rx="2" />
        <rect x="65" y="50" width="30" height="40" fill="#0f172a" rx="2" />
        <rect x="10" y="40" width="10" height="30" fill="#0f172a" rx="2" />

        {/* Route Line with Neon Glow */}
        <polyline
          points={pathPoints.map(p => `${p.x},${p.y}`).join(' ')}
          fill="none"
          stroke="#3b82f6"
          strokeWidth="1"
          strokeDasharray="2,1"
          opacity={isTracking ? 1 : 0.4}
          filter="drop-shadow(0 0 2px #3b82f6)"
        />

        {/* Checkpoints */}
        <circle cx={pathPoints[0].x} cy={pathPoints[0].y} r="1.5" fill="#3b82f6" opacity="0.5" />
        <circle cx={pathPoints[pathPoints.length-1].x} cy={pathPoints[pathPoints.length-1].y} r="1.5" fill="#22c55e" opacity="0.5" />
      </svg>

      {/* Pulsing Car Icon */}
      <div 
        className="absolute w-10 h-10 flex items-center justify-center transition-transform duration-75"
        style={{ 
          left: `${carPos.x}%`, 
          top: `${carPos.y}%`,
          transform: `translate(-50%, -50%) rotate(${rotation}deg)`
        }}
      >
        <div className="absolute w-full h-full bg-blue-500/20 rounded-full animate-ping"></div>
        <span className="text-3xl filter drop-shadow-[0_0_8px_rgba(59,130,246,0.8)]">🏎️</span>
      </div>

      {/* Map Labels */}
      <div className="absolute top-6 left-6 flex flex-col gap-1 pointer-events-none">
        <span className="text-[10px] font-black text-blue-500 uppercase tracking-[0.2em]">GPS Active</span>
        <span className="text-xs text-slate-400 font-medium">{isTracking ? 'En route to destination' : 'Satellite connected'}</span>
      </div>
    </div>
  );
};

export default MapVisualizer;
